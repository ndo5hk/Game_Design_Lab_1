package edu.virginia.lab1test;

import java.beans.EventHandler;

public class mouseEventHandler extends EventHandler {

	public mouseEventHandler(Object target, String action, String eventPropertyName, String listenerMethodName) {
		super(target, action, eventPropertyName, listenerMethodName);
		// TODO Auto-generated constructor stub
	}

}
