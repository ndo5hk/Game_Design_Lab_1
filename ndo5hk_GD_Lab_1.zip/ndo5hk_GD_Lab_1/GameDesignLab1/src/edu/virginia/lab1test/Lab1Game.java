package edu.virginia.lab1test;

import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import edu.virginia.engine.display.Game;
import edu.virginia.engine.display.Sprite;
import edu.virginia.engine.util.GameClock;

/**
 * Example game that utilizes our engine. We can create a simple prototype game with just a couple lines of code
 * although, for now, it won't be a very fun game :)
 * */
public class Lab1Game extends Game implements MouseListener{

	/* Create a sprite object for our game. We'll use mario */
	static Sprite mario = new Sprite("Mario", "Mario.png");
	static int xPos;
	static int yPos;
	static int points = 25;
	boolean mousePressed = false;
	boolean mouseOverMario = false;
	static GameClock clock = new GameClock();
	
	/**
	 * Constructor. See constructor in Game.java for details on the parameters given
	 * */
	public Lab1Game() {
		super("Lab One Test Game", 500, 300);
		super.getMainFrame().addMouseListener(this);
	}
	
	/**
	 * Engine will automatically call this update method once per frame and pass to us
	 * the set of keys (as strings) that are currently being pressed down
	 * */
	@Override
	public void update(ArrayList<Integer> pressedKeys){
		if (pressedKeys.size() >0 && points > 0 && 30-(int)clock.getElapsedTime()/1000 >= 0) {
			if (pressedKeys.contains(38)) {
				yPos-=4;
			}
			if (pressedKeys.contains(39)) {
				xPos+=4;
			}
			if (pressedKeys.contains(37)) {
				xPos-=4;
			}
			if (pressedKeys.contains(40)) {
				yPos+=4;
			}
		}
		
		super.update(pressedKeys);
		
		/* Make sure mario is not null. Sometimes Swing can auto cause an extra frame to go before everything is initialized */
		if(mario != null) mario.update(pressedKeys);
	}
	
	/**
	 * Engine automatically invokes draw() every frame as well. If we want to make sure mario gets drawn to
	 * the screen, we need to make sure to override this method and call mario's draw method.
	 * */
	@Override
	public void draw(Graphics g){
		g.translate(xPos, yPos);
		super.draw(g);
		
		/* Same, just check for null in case a frame gets thrown in before Mario is initialized */
		if(mario != null) mario.draw(g);
		g.translate(-xPos, -yPos);
		g.drawString("Life: " + Integer.toString(points), 18, 20);
		
		if (points <= 0) {
			g.drawString("Mario Lost!", 210, 130);
		} else if (30-(int)clock.getElapsedTime()/1000 >= 0){
			g.drawString("Time: " + Integer.toString(30-(int)clock.getElapsedTime()/1000), 425, 20);
		}
		
		if (30-(int)clock.getElapsedTime()/1000 < 0) {
			g.drawString("Clicker Lost!", 210, 130);
		}
		
	}

	/**
	 * Quick main class that simply creates an instance of our game and starts the timer
	 * that calls update() and draw() every frame
	 * */
	public static void main(String[] args) {
		Lab1Game game = new Lab1Game();
		clock.resetGameClock();
		game.start();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (points > 0 && 30-(int)clock.getElapsedTime()/1000 >= 0) {
			if (e.getX() > xPos+15 && e.getX() < xPos+108 && e.getY() > yPos+20 && e.getY() < yPos+153) {
				points--;
			}
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
